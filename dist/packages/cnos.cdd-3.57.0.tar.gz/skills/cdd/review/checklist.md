# Review Checklist

Pre-submit and review checklist. Both author and reviewer must verify.

## P0 — Governance

- [ ] **P0.1 No self-merge.** Author never merges own diff to main unless human explicitly instructs.
- [ ] **P0.2 Branch current.** Rebased on main. No missing commits from main.

## P1 — Process

- [ ] **P1.1 Author rebases.** Reviewer never rebases. Reviewer's time > author's time.
- [ ] **P1.2 Only author deletes branch.** Reviewer returns branches, never deletes.

## P2 — Quality

- [ ] **P2.1 Purpose.** Solves stated problem?
- [ ] **P2.2 Simplicity.** Simplest solution?
- [ ] **P2.3 Necessity.** No unnecessary additions?
- [ ] **P2.4 Types.** Correct and semantic?
- [ ] **P2.5 Edge cases.** Handled?
- [ ] **P2.6 Tests.** Tested?
- [ ] **P2.7 History.** Clean commits?
- [ ] **P2.8 Builds clean.** `dune build` succeeds with no warnings-as-errors. Check: variant constructors in bare let-bindings need type annotations (labeled args infer, tuples/lets don't).
- [ ] **P2.9 Unicode hygiene.** Visible Unicode (emoji, em dashes, arrows) is allowed in human-facing content (templates, docs). Hidden or bidirectional control characters (U+200B..U+200F, U+202A..U+202E, U+2066..U+2069, U+FEFF, category Cf) are disallowed unless explicitly justified. GitHub's "hidden characters" warning targets the latter, not the former — do not block on visible Unicode in content files.

---

**Author:** Verify P0 + P1 before pushing branch.

**Reviewer:** Verify all. If P0 fails → REQUEST REBASE or reject.
